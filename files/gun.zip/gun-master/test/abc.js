var expect = global.expect = require("./expect");
require('./common');