import { IGunStatic } from './types/static';
declare global {
    var Gun: IGunStatic;
}
